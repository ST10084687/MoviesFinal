﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using MoviesFinal.Models;

namespace MoviesFinal.Data
{
    public class MoviesFinalContext : DbContext
    {
        public MoviesFinalContext (DbContextOptions<MoviesFinalContext> options)
            : base(options)
        {
        }

        public DbSet<MoviesFinal.Models.Movie>? Movie { get; set; }

        public DbSet<MoviesFinal.Models.Genre>? Genre { get; set; }
    }
}
