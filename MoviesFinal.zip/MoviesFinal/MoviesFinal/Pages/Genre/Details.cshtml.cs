﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using MoviesFinal.Data;
using MoviesFinal.Models;

namespace MoviesFinal.Pages.Genre
{
    public class DetailsModel : PageModel
    {
        private readonly MoviesFinal.Data.MoviesFinalContext _context;

        public DetailsModel(MoviesFinal.Data.MoviesFinalContext context)
        {
            _context = context;
        }

      public Genre Genre { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.Genre == null)
            {
                return NotFound();
            }

            var genre = await _context.Genre.FirstOrDefaultAsync(m => m.GenreID == id);
            if (genre == null)
            {
                return NotFound();
            }
            else 
            {
                Genre = genre;
            }
            return Page();
        }
    }
}
